import { Injectable } from '@angular/core';
import { User } from '../../user';

@Injectable({
  providedIn: 'root'
})
export class StorageService {

  loggedInUser: User;

  getLoggedInUser() {
    return this.loggedInUser;
  }

  constructor() { }
}
