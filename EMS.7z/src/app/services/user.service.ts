import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  url: string = "http://localhost:8080";

  constructor(private http: HttpClient) { }

  getAllRegisteredOrganizations() {
    return this.http.get(this.url + "/users/getAllRegisteredOrganizations").pipe();
  }

  login(email, password) {
    let user = {
      'email': email,
      'password': password
    };
    return this.http.post(this.url+"/users/login", user).pipe();
  }

  getAllUsersUnderAdmin(userId){
    return this.http.get(this.url+"/users/underAdmin/"+userId).pipe();
  }

  addUserUnderAdmin(user){
    return this.http.post(this.url+"/users/addUserUnderAdmin", user).pipe();
  }

}
