import { Parameter } from "./parameter";

export class Site{

    siteId: string;
    userId: string;
    siteName: string;

    postURL: string;
    schemaURL: string;

    deviceName: string;
    deviceModel: string;
    deviceManuf: string;
    deviceAddress: string;

    parameters: Parameter[];

}