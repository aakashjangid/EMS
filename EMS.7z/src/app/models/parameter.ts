export class Parameter {

    parameterId: string;
    siteId: string;
    address: string;

    label: string;
    acronym: string;
    type: string;
    measuringUnit: string;

    highValue: string;
    lowValue: string;
    highFault: string;
    lowFault: string;

}