import { BrowserModule } from '@angular/platform-browser';
import { NgModule, NO_ERRORS_SCHEMA } from '@angular/core';
import { DatePipe } from '@angular/common'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { MDBBootstrapModule } from 'angular-bootstrap-md';

import { AppComponent } from './app.component';
import { Routes, RouterModule } from '@angular/router';

import { LoginService } from './services/login.service';

import { HttpClientModule } from '@angular/common/http';

import { AgmCoreModule } from '@agm/core';
import { DynamicGraphComponent } from './components/dynamic-graph/dynamic-graph.component';
import { StaticGraphComponent } from './components/static-graph/static-graph.component';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { StaticGraphDialog } from './components/static-graph/static-graph.component'
import { NgDraggableWidgetModule } from 'ngx-draggable-widget';

import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { MatDialogModule } from '@angular/material/dialog';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatFormFieldModule, MatInputModule } from '@angular/material';
import { MatStepperModule } from '@angular/material/stepper';
import { MatNativeDateModule } from '@angular/material';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
import {MatTableModule} from '@angular/material/table';

import { WidgethomeComponent } from './components/widgethome/widgethome.component';

import { Ng2GoogleChartsModule } from 'ng2-google-charts';

import { LocationStrategy, HashLocationStrategy } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { HomeComponent } from './components/home/home.component';
import { Home1Component } from './components/home1/home1.component';
import { SideNavComponent } from './components/side-nav/side-nav.component';
import { SiteConfigComponent } from './components/site-config/site-config.component';
import { GeneralConfigComponent } from './components/general-config/general-config.component';
import { ShowSiteInfoComponent } from './components/show-site-info/show-site-info.component';
import { NewParameterComponent } from './components/new-parameter/new-parameter.component';
import { LoginComponent } from './components/login/login.component';
import { OrgListComponent } from './components/org-list/org-list.component';
import { UserlistComponent } from './components/userlist/userlist.component';

const appRoutes: Routes = [
  { path: 'dyGraph', component: DynamicGraphComponent },
  { path: 'stGraph', component: StaticGraphComponent },
  { path: 'siteInfo', component: WidgethomeComponent },
  { path: 'home', component: HomeComponent },
  { path: 'home1', component: Home1Component },
  { path: '', redirectTo: '/login', pathMatch: 'full' },
  { path: 'userList', component: UserlistComponent },
  { path: 'orgList', component: OrgListComponent },
  { path: 'siteConfig', component: SiteConfigComponent },
  { path: 'siteInfo1', component: ShowSiteInfoComponent },
  { path: 'login', component: LoginComponent },
  { path: 'general', component: GeneralConfigComponent },
];

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    HomeComponent,
    Home1Component,
    DynamicGraphComponent,
    StaticGraphComponent,
    NavBarComponent,
    StaticGraphDialog,
    WidgethomeComponent,
    UserlistComponent,
    HeaderComponent,
    SideNavComponent,
    SiteConfigComponent,
    GeneralConfigComponent,
    ShowSiteInfoComponent,
    NewParameterComponent,
    OrgListComponent
  ],
  imports: [
    BrowserModule,
    MatDialogModule,
    BrowserAnimationsModule,
    MDBBootstrapModule.forRoot(),
    Ng2GoogleChartsModule,
    FormsModule,
    HttpClientModule,
    NgDraggableWidgetModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatIconModule,
    MatSelectModule,
    MatFormFieldModule,
    MatInputModule,
    RouterModule.forRoot(appRoutes),
    AgmCoreModule.forRoot({
      apiKey: 'AIzaSyCoegRRdaK7vfJV75rTUVmydXNfJAXUbYY'
    }),
    MatStepperModule,
    ReactiveFormsModule,
    MatTableModule

  ],
  entryComponents: [
    StaticGraphDialog
  ],
  providers: [
    LoginService,
    MatNativeDateModule,
    DatePipe, { provide: LocationStrategy, useClass: HashLocationStrategy }
  ],
  bootstrap: [AppComponent],
  schemas: [NO_ERRORS_SCHEMA]
})
export class AppModule { }
