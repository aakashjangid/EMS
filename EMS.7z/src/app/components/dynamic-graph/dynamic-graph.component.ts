import { Component, OnInit } from '@angular/core';
import { Chart } from 'Chart.js';
import { ViewChild } from '@angular/core'

@Component({
  selector: 'app-dynamic-graph',
  templateUrl: './dynamic-graph.component.html',
  styleUrls: ['./dynamic-graph.component.css']
})
export class DynamicGraphComponent implements OnInit {
  @ViewChild('linedynamicChart') private dynamicChartRef;
  dynamicChart: any;

  dynamicChartData =  {
    chartType: 'LineChart',
  
    dataTable: [
      ['Voltage', 'voltage in volts'],
      ['initial',     0],
      
    ],
    options: {'title': 'Voltage',
    'curveType':'function',
    'legend':{'position':'bottom'},
  },
  };

  // voltageSocket: WebSocket = new WebSocket('ws://iot-env.ap-south-1.elasticbeanstalk.com:8080/voltageapi');
  // currentSocket: WebSocket = new WebSocket('ws://iot-env.ap-south-1.elasticbeanstalk.com:8080/currentapi');

  
  
anysocket:WebSocket;

  constructor() {
    // var self=this;
    //     this.anysocket = new WebSocket("ws");
    // this.anysocket.onmessage = function (event) {
    //   console.log(event);
    //   var obj = JSON.parse(event.data);
    //   self.dynamicChartData = Object.create(self.dynamicChartData);
      
    //   self.dynamicChartData.dataTable.push([obj.date,obj.value]);
    //   // var datainsert:number;
    //   // datainsert=message.data;
    //   // self.dynamicChart.data.labels.push('a');
    //   // self.dynamicChart.data.datasets[0].data.push(message.data);
    //   // self.dynamicChart.update(); 
    // }
    // self.dynamicChart = Object.create(self.dynamicChartData); 
    
  }
open:boolean;
  changeParameterAndGraph(parameter){
    parameter=parameter.value;
    if(this.open){
      this.anysocket.close();
    }
   
  this.anysocket = new WebSocket('ws://localhost:8080/dynamicwebsocketapi/'+parameter);
  this.open=true;
  this.dynamicChartData.dataTable.length=2;
  this.dynamicChartData = Object.create(this.dynamicChartData);
  this.dynamicChartData.dataTable[0] = [parameter,'unit'];
  this.dynamicChartData.options.title=parameter;
  var self = this;
  this.anysocket.onmessage = function (event) {
    
    console.log(event);
    var obj = JSON.parse(event.data);
    self.dynamicChartData = Object.create(self.dynamicChartData);
    
    self.dynamicChartData.dataTable.push([obj.date,obj.value]);
    // var datainsert:number;
    // datainsert=message.data;
    // self.dynamicChart.data.labels.push('a');
    // self.dynamicChart.data.datasets[0].data.push(message.data);
    // self.dynamicChart.update(); 
  }
  
  
  console.log(this.dynamicChartData.dataTable);
  }

  ngOnInit() {
    




  }

}
