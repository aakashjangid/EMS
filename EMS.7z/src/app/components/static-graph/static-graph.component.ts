import { Component, OnInit } from '@angular/core';
import { ViewChild } from '@angular/core'
import { StaticGraphService } from '../../static-graph.service'
import {MatDialog} from '@angular/material';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import {GoogleChartComponent} from 'ng2-google-charts';

@Component({
  selector: 'app-static-graph',
  templateUrl: './static-graph.component.html',
  styleUrls: ['./static-graph.component.css']
})
export class StaticGraphComponent implements OnInit {
  @ViewChild('cchart') private cchart:GoogleChartComponent;

  
  staticChartData =  {
    chartType: 'LineChart',
  
    dataTable: [
      ['Voltage', 'voltage in volts'],
      ['initial',     0],
      
    ],
    options: {'title': 'Voltage',
    'curveType':'function',
    'legend':{'position':'bottom'},
  },
  };

  BasicEntity: {
    id: Number;
    voltage: Number;
    current: Number
  }
  constructor(private staticGraphService: StaticGraphService,public dialog: MatDialog) {

    var self = this;
    
  }

  ngOnInit() {
    
    this.staticGraphService.getData().subscribe(
      
      (data: any[]) => {
        // let googleChartWrapper = this.cchart.wrapper;
        this.staticChartData = Object.create(this.staticChartData);
        data.forEach(BasicEntity => {
          
          this.staticChartData.dataTable.push([BasicEntity[2],BasicEntity[0]]);
         
        });

      },
      error => {
        console.log(error.error.text);

      });

      

  }

changeParameterAndChart(paramName:string){
  this.staticChartData.dataTable[0] = [paramName,'unit'];
  this.staticChartData.options.title = paramName;
  this.staticGraphService.getDataForParam(paramName).subscribe(
      
    (data: any[]) => {
      // let googleChartWrapper = this.cchart.wrapper;
      this.staticChartData = Object.create(this.staticChartData);
      data.forEach(BasicEntity => {
        
        this.staticChartData.dataTable.push([BasicEntity[2],BasicEntity[0]]);
       
      });

    },
    error => {
      console.log(error.error.text);

    });

}

  maximizeWidget(event) {
    
    const dialogRef = this.dialog.open(StaticGraphDialog);
    
    dialogRef.afterClosed().subscribe(result => {
      console.log(`Dialog result: ${result}`);
    });
  }


}

@Component({
  selector: 'static-graph-modal',
  templateUrl: './static-graph-modal.html',
})
export class StaticGraphDialog implements OnInit{

  @ViewChild('cchart') private cchart:GoogleChartComponent;
  // staticChart: any;
  
  startDate:Date;
  endDate:Date;

  staticChartDataModal =  {
    chartType: 'LineChart',
  
    dataTable: [
      ['Voltage', 'voltage in volts'],
      ['initial',     0],
      
    ],
    options: {'title': 'Voltage',
    'curveType':'function',
    'legend':{'position':'bottom'}
  },
  };

  BasicEntity: {
    id: Number;
    voltage: Number;
    current: Number
  }
  constructor(private staticGraphService: StaticGraphService,public dialog: MatDialog) {

    // var self = this;
   
    this.staticGraphService.getData().subscribe(
      (data: any[]) => {
        
        data.forEach(BasicEntity => {
          this.staticChartDataModal = Object.create(this.staticChartDataModal);
          this.staticChartDataModal.dataTable.push([BasicEntity[2],BasicEntity[0]]);
          console.log(this.staticChartDataModal.dataTable);
          
          // this.staticChart.data.labels.push(BasicEntity[2]);
          // this.staticChart.data.datasets[0].data.push(BasicEntity[0]);
          // this.staticChart.data.datasets[1].data.push(BasicEntity[1]);
          // this.staticChart.update();
        });

      },
      error => {
        console.log(error.error.text);

      });

  }

  ngOnInit() {
    
    



  }

  

  startDateSelected(type: string, event: MatDatepickerInputEvent<Date>) {
    this.startDate=event.value;
    console.log(this.startDate);
  }
  endDateSelected(type: string, event: MatDatepickerInputEvent<Date>) {
    this.endDate=event.value;
    this.staticGraphService.getDataForDates(this.startDate,this.endDate).subscribe(
      (data: any[]) => {
        console.log(data);
        this.staticChartDataModal.dataTable.length=2;
        this.staticChartDataModal = Object.create(this.staticChartDataModal);
        data.forEach(BasicEntity => {
          
          this.staticChartDataModal.dataTable.push([BasicEntity[2],BasicEntity[0]]);
          
          
          
          
        });
        
      },
      error => {
        console.log(error.error.text);
  
      });

    }

    changeParameterAndChart(event){
      var paramName = event.value;
      this.staticChartDataModal.dataTable.length=2;
      this.staticChartDataModal.dataTable[0] = [paramName,'unit'];
      this.staticChartDataModal.options.title = paramName;
      this.staticGraphService.getDataForParam(paramName).subscribe(
          
        (data: any[]) => {
          // let googleChartWrapper = this.cchart.wrapper;
          this.staticChartDataModal = Object.create(this.staticChartDataModal);
          data.forEach(BasicEntity => {
            
            this.staticChartDataModal.dataTable.push([BasicEntity[2],BasicEntity[0]]);
           
          });
    
        },
        error => {
          console.log(error.error.text);
    
        });
    
    }

  }