import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowSiteInfoComponent } from './show-site-info.component';

describe('ShowSiteInfoComponent', () => {
  let component: ShowSiteInfoComponent;
  let fixture: ComponentFixture<ShowSiteInfoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowSiteInfoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowSiteInfoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
