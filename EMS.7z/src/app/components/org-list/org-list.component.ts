import { Component, OnInit } from '@angular/core';
import { User } from '../../../user';
import { UserService } from '../../services/user.service';
import { StorageService } from '../../services/storage.service';

@Component({
  selector: 'app-org-list',
  templateUrl: './org-list.component.html',
  styleUrls: ['./org-list.component.css']
})
export class OrgListComponent implements OnInit {

  users: User[] = [];
  loggedInUser: User;

  constructor(private userService: UserService, private storageService: StorageService) { 
  }

  ngOnInit() {
    this.getAllRegisteredOrganizations();
  }

  getAllRegisteredOrganizations(){
    this.userService.getAllRegisteredOrganizations().subscribe(
      data =>{
        this.users = data as any;
      },
      error =>{
        console.log("Error in getAllRegisteredOrganizations", error);
      }
    );
  }

}
