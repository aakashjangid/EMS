import { Component, OnInit } from '@angular/core';
import { User } from '../../../user';
import { UserService } from '../../services/user.service';

@Component({
  selector: 'app-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.css']
})
export class UserlistComponent implements OnInit {

  users: User[] = [];
  loggedInUser: User;

  name:string;
  contact;
  email:string;
  password:string;

  constructor(private userService: UserService) { 
    this.loggedInUser = JSON.parse(localStorage.getItem('user'));
  }

  ngOnInit() {
    this.getAllRegisteredOrganizations();
  }

  getAllRegisteredOrganizations(){
    this.userService.getAllUsersUnderAdmin(this.loggedInUser.id).subscribe(
      data =>{
        this.users = data as any;
      },
      error =>{
        console.log("Error in getAllRegisteredOrganizations", error);
      }
    );
  }

  addUser(){
    if(!(this.name && this.contact && this.email && this.password)){
      window.alert("Please Fill all the fields")
    }else{
      let user = {
        'name':this.name,
        'contact': this.contact,
        'email': this.email,
        'password': this.password,
        'orgName': this.loggedInUser.orgName
      };
      this.userService.addUserUnderAdmin(user).subscribe(
        data =>{
          this.users = data as any;
        }, error =>{
          console.log("Error in adding user", error);
        }
      );
    }
  }

}
