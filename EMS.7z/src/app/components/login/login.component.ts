import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UserService } from '../../services/user.service';
import { User } from '../../../user';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email: string;
  password: string;
  register: boolean = false;
  firstName: string;
  lastName: string;
  registrationSuccess: boolean = false;
  emailExists: boolean = false;
  invalidUser: boolean = false;

  loggedInUser: User;

  constructor(private userService: UserService, private router: Router) {

  }

  ngOnInit() {
  }

  doLogin() {
    this.userService.login(this.email, this.password).subscribe(
      data =>{
        this.loggedInUser = data as User;
        localStorage.setItem('user', JSON.stringify(this.loggedInUser));
        localStorage.setItem('userId', JSON.stringify(this.loggedInUser.id));
        if(this.loggedInUser.role == 0){
          this.router.navigate(['/home1']);
        }else{
          this.router.navigate(['/home']);
        }
        
      }, error =>{
        console.log('Login Error', error
      )
      }
    );
  }

  toggleForm() {
    this.register = !this.register;
  }

  doRegister() {

  }
}