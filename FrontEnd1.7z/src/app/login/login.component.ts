import { Component, OnInit } from '@angular/core';
import { LoginService } from '../services/login.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email: string;
  password: string;
  register: boolean = false;
  firstName: string;
  lastName: string;
  registrationSuccess: boolean = false;
  emailExists: boolean = false;
  invalidUser:boolean = false;

  constructor(private loginService: LoginService) { }

  ngOnInit() {
  }

  doLogin() {
    this.loginService.login(this.email, this.password).subscribe(
      data => {
        console.log("Login Successful ", data);
        localStorage.setItem("user", data);
      },
      error => {
        console.log("Error", error);
        this.invalidUser=true;
      });
  }

  toggleForm() {
    this.register = !this.register;
  }

  doRegister() {
    this.loginService.register(this.firstName, this.lastName, this.email, this.password).subscribe(
      data => {
        console.log("Registration Successful ", data);
        if (data == true) {
          this.registrationSuccess = true;

        } else {
          this.emailExists = true;
        }
      }, error => {
        console.log("Error", error);
      }
    )
  }

}
