package com.bettercode.yammer.model;

public class Share {

}
