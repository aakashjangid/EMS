package com.bettercode.yammer.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bettercode.yammer.model.Post;

public class PostMapper implements RowMapper<Post> {

	public Post mapRow(ResultSet rs, int rowNum) throws SQLException {
		Post post = new Post();
		post.setPost_id(rs.getInt("post_id"));
		post.setUser_id(rs.getInt("user_id"));
		return post;
	}

}
