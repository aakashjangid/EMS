package com.bettercode.yammer.serviceimpl;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Service;

import com.bettercode.yammer.dao.UserDAO;
import com.bettercode.yammer.model.User;
import com.bettercode.yammer.rowmapper.UserMapper;
import com.bettercode.yammer.service.UserService;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public User authenticate(User user) {
		String sql = "SELECT * FROM users WHERE email=? AND password=?";
		Object[] params = new Object[] { user.getEmail(), user.getPassword() };
		return jdbcTemplate.queryForObject(sql, params, new UserMapper());
	}

	public boolean registerNewUser(User user) {
		return userDAO.registerNewUser(user);
	}

}