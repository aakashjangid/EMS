package com.bettercode.yammer.daoimpl;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bettercode.yammer.dao.UserDAO;
import com.bettercode.yammer.model.User;

@Repository
public class UserDAOImpl implements UserDAO {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public boolean registerNewUser(User user) {
		String sql = "INSERT INTO users(firstName, lastName, email, password) VALUES(?,?,?,?)";
		try {
			jdbcTemplate.update(sql, user.getFirstName(), user.getLastName(), user.getEmail(), user.getPassword());
			return true;
		} catch (Exception e) {
			System.out.println(e.getClass());
			e.printStackTrace();
			return false;
		}
	}

}
