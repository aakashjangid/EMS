package com.bettercode.yammer.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bettercode.yammer.model.Comment;

public class CommentMapper implements RowMapper<Comment> {

	public Comment mapRow(ResultSet rs, int rowNum) throws SQLException {
		Comment comment = new Comment();
		comment.setComment_id(rs.getInt("comment_id"));
		comment.setPost_id(rs.getInt("post_id"));
		comment.setUser_id(rs.getInt("user_id"));
		return comment;
	}

}
