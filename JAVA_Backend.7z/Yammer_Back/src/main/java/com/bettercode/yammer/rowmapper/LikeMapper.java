package com.bettercode.yammer.rowmapper;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.bettercode.yammer.model.Like;

public class LikeMapper implements RowMapper<Like> {

	public Like mapRow(ResultSet rs, int rowNum) throws SQLException {
		Like like= new Like();
		like.setLike_id(rs.getInt("like_id"));
		like.setUser_id(rs.getInt("user_id"));
		return like;
	}

}
