package com.bettercode.yammer.daoimpl;

import java.util.List;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.bettercode.yammer.model.Comment;
import com.bettercode.yammer.model.Like;
import com.bettercode.yammer.model.Post;
import com.bettercode.yammer.rowmapper.CommentMapper;
import com.bettercode.yammer.rowmapper.LikeMapper;
import com.bettercode.yammer.rowmapper.PostMapper;

@Repository
public class PostDAOImpl {

	private JdbcTemplate jdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.jdbcTemplate = new JdbcTemplate(dataSource);
	}

	public List<Post> getAllPosts() {
		List<Post> posts;

		String sqlPost = "SELECT * FROM posts";
		posts = jdbcTemplate.query(sqlPost, new PostMapper());
		List<Like> likes;
		List<Comment> comments;

		for (Post post : posts) {

			String sqlLikes = "SELECT * FROM likes WHERE post_id=" + post.getPost_id();
			likes = jdbcTemplate.query(sqlLikes, new LikeMapper());
			post.setLikes(likes);

			String sqlComments = "SELECT * FROM comments WHERE post_id=" + post.getPost_id();
			comments = jdbcTemplate.query(sqlComments, new CommentMapper());
			post.setComments(comments);

		}

		return posts;
	}

}
