package com.bettercode.yammer.service;

import com.bettercode.yammer.model.User;

public interface UserService {

	public boolean registerNewUser(User user);

	public User authenticate(User user);

}
