package com.bettercode.yammer.dao;

import com.bettercode.yammer.model.User;

public interface UserDAO {

	public boolean registerNewUser(User user);
	
}
