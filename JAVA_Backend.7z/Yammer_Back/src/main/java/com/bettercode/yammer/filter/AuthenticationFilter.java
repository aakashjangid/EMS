package com.bettercode.yammer.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebFilter("/*")
public class AuthenticationFilter implements Filter{

	public void destroy() {
		
	}
	
	//TODO : Add the error in constants class.
	//TODO : To check Which URL's need to be by-passed by filter. Try to mention them also in constants class.
	
	// TODO :  Implement nested if-else logic and make it exclude the login and registration URLs.

	public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
			throws IOException, ServletException {
		String path = ((HttpServletRequest)req).getServletPath();
		chain.doFilter(req, res);
		
	}

	public void init(FilterConfig arg0) throws ServletException {
		
	}

}
